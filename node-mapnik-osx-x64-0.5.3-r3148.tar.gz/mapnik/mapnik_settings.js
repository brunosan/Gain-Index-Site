var path = require('path');

module.exports.paths = {
    'fonts': path.join(__dirname, 'fonts'),
    'input_plugins': path.join(__dirname, 'input')
};
